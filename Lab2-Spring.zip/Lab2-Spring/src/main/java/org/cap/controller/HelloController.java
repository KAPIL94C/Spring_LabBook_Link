package org.cap.controller;

import java.awt.List;

import org.cap.entities.Trainee;
import org.cap.service.ITraineeService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class HelloController {
    private static Logger Log= LoggerFactory.getLogger(HelloController.class);

    @Autowired
    private ITraineeService traineeService;


    /**
      this method will run on get request /hello
    **/
    @GetMapping("/")
  // @RequestMapping(method = {RequestMethod.GET}, value = "/hello")
    public ModelAndView sayHello() {
        Log.info("inside hello");
        return new ModelAndView("login",  "message", "Welcome user");
    }
    
    @GetMapping("/processlogin")
    public ModelAndView traineeLogin(@RequestParam("empname")String empname,@RequestParam("password")String password) {
        if(empname.contentEquals("admin")&& password.contentEquals("admin")){
        return new ModelAndView("alloperations");
        } 
        else {
        String value="Invalid Id/Password";
        return new ModelAndView("Error","msg",value);
    }
    }
    

    @GetMapping("/find")
    public ModelAndView findPage() {
        return new ModelAndView("findtrainee");
    }

    @GetMapping("/processfindtrainee")
    public ModelAndView traineeDetails(@RequestParam("empid")int empId) {
        Trainee trainee= traineeService.findById(empId);
        if(trainee!=null){
        return new ModelAndView("traineedetails", "trainee", trainee);
        }else {
        	String msg="Trainee Does Not Exists";
        	return new ModelAndView("Error", "msg", msg);
        	
        }
        }
    
    @GetMapping("/modify")
    public ModelAndView modifyPage() {
        return new ModelAndView("modifytrainee");
    }
    
    @GetMapping("/processmodifytrainee")
    public ModelAndView modifytraineePage(@RequestParam("empid")int empId) {
    	Trainee item= traineeService.findById(empId);
    	if(item !=null)
        return new ModelAndView("edittrainee", "item", item);	
    	else {
    		String msg="Trainee Does Not Exists";
        	return new ModelAndView("Error", "msg", msg);
    	}
    }
    
    @GetMapping("/retriveall")
    public ModelAndView findall() {
         java.util.List<Trainee> list = traineeService.fetchAll();
        return new ModelAndView("alltraineedetails","list",list);
    }
    
    @GetMapping("/delete")
    public ModelAndView delete() {
        return new ModelAndView("deletetrainee");// only provide view name
    }
    
    @GetMapping("/deletetrainee")
    public ModelAndView DeleteTrainee(@RequestParam("empId") int empId) {
        boolean result =traineeService.delete(empId);
         if(result ==true) {
    	return new ModelAndView("somevalue","value",result);
    }else {
    	String msg="Trainee Does Not Exists";
    	return new ModelAndView("Error","msg",msg);
    }
    }

    @GetMapping("/register")
    public ModelAndView registerPage() {
        return new ModelAndView("traineeregister");// only provide view name
    }
    
  @GetMapping("/processregister")
  public ModelAndView registerEmployee(@RequestParam("id") String empId,@RequestParam("name") String empName,@RequestParam("location") String location,@RequestParam("domain") String domain ) {
  	Trainee trainee=new Trainee();
      trainee.setTraineeId(Integer.parseInt(empId));
      trainee.setTraineeName(empName);
      trainee.setTraineeLocation(location);
      trainee.setTraineeDomain(domain);
      trainee=traineeService.save(trainee);
      return new ModelAndView("traineedetails",  "trainee", trainee);
  }
  


}
