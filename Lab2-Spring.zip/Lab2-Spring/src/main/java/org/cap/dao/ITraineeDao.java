package org.cap.dao;

import org.cap.entities.Trainee;

import java.util.List;

public interface ITraineeDao {

	Trainee findById(int id);

    Trainee save(Trainee user);

    List<Trainee> fetchAll();
    
    boolean delete(int id);

}
