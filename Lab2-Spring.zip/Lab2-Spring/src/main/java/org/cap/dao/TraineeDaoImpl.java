package org.cap.dao;

import org.cap.entities.Trainee;
import org.cap.exceptions.MobileNoAlreadyExistsException;
import org.springframework.stereotype.Repository;
import javax.persistence.*;
import java.util.List;

@Repository
public class TraineeDaoImpl implements ITraineeDao {

    private EntityManager entityManager;

    public EntityManager getEntityManager() {
        return entityManager;
    }

    @PersistenceContext
    public void setEntityManager(EntityManager entityManager) {
        this.entityManager = entityManager;
    }


    @Override
    public Trainee findById(int id) {
    	Trainee user = entityManager.find(Trainee.class, id);         //if needed Employees change
        return user;
    }


    @Override
    public List<Trainee> fetchAll(){
        String jql = "from Trainee";
        TypedQuery<Trainee> query = entityManager.createQuery(jql, Trainee.class);
        List<Trainee> list = query.getResultList();
        return list;

    }

    @Override
    public Trainee save(Trainee trainee) {
    	trainee = getEntityManager().merge(trainee);
        return trainee;
    }

	@Override
	public boolean delete(int id) {
		Trainee user = entityManager.find(Trainee.class, id); 
		if(user!=null) {
	    entityManager.remove(user);
		return true;
		}else {
			return false;
		}
	}

}
