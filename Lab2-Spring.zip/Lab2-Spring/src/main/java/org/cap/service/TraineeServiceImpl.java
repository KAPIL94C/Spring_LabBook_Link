package org.cap.service;

import org.cap.dao.ITraineeDao;
import org.cap.entities.Trainee;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;


@Service
@Transactional
public class TraineeServiceImpl implements ITraineeService {

    private ITraineeDao traineeDao;

    public ITraineeDao getEmployeeDao() {
        return traineeDao;
    }

    @Autowired
    public void setEmployeeDao(ITraineeDao dao) {
        this.traineeDao = dao;
    }

    @Override
    public Trainee findById(int id) {
        return traineeDao.findById(id);
    }

    @Override
    public Trainee save(Trainee trainee) {
        return traineeDao.save(trainee);
    }

    @Override
    public List<Trainee> fetchAll() {
        return traineeDao.fetchAll();
    }

	@Override
	public boolean delete(int id) {
		boolean result=traineeDao.delete(id);
		return result;
	}
}
