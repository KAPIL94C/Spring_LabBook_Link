package com.capg.dao;

import com.capg.entities.Employee;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import java.util.*;

/**
 * @Repository is recommended instead of @Component on EmployeeDaoImpl to show intention
 * Both @Repository and @Component does same job
 */
@Component
public class EmployeeDaoImpl implements IEmployeeDao{

    private Map<Integer,Employee>map=new HashMap<>();

    public EmployeeDaoImpl(){
    	Employee e=new Employee();
    	e.setEmployeeId(1234);
    	e.setEmployeeName("Harriet");
    	e.setSalary(40000);
    	e.setBusinessUnit("PES-BU");
    	e.setAge(30);
    	 map.put(e.getEmployeeId() , e);	
    	  
    	  
    			System.out.println("inside dao constructor");
     //   System.out.println("beta check in");
    }
    
    


    @Override
    public List<Employee> fetchAllEmployees() {
        Collection<Employee>employees=map.values();
        List<Employee>list=new ArrayList<>(employees);
        return list;
    }
    @Override
	public Employee findById(int id) {
		
	    Employee emp=map.get(id);
	return emp;
	}
}
