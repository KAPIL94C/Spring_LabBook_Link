package com.capg.service;

import com.capg.entities.Employee;

import java.util.List;

public interface IEmployeeService {
    List<Employee>fetchAllEmployees();
    
    Employee findById(int id);

}
