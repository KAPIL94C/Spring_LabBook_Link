package org.cap.controller;

import org.cap.dto.ProductDto;
import org.cap.entities.Product;
import org.cap.service.IProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class CustomerRestController {

    @Autowired
    private IProductService service;

    @PostMapping("/products/add")
    public ResponseEntity<Product>addProduct(@RequestBody ProductDto dto){
        Product product=convert(dto);
        service.save(product);
        ResponseEntity<Product>response=new ResponseEntity<>(product, HttpStatus.OK);
        return response;
    }

    

    @GetMapping("/products")
    public ResponseEntity<List<Product>>fetchAll(){
     List<Product>product=  service.fetchAll();
     ResponseEntity<List<Product>>response=new ResponseEntity<>(product,HttpStatus.OK);
     return response;
    }

   

    


    public Product convert(ProductDto dto){
        Product product=new Product();
        product.setProdId(dto.getProdId());
        product.setProdName(dto.getProdName());
        product.setProdPrice(dto.getProdPrice());
        return product;
    }


}
