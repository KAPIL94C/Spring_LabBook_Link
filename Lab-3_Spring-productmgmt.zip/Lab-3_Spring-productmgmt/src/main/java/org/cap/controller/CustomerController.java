package org.cap.controller;

import java.awt.List;
import java.util.ArrayList;

import org.cap.entities.Product;
import org.cap.service.IProductService;
import org.cap.util.SessionData;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class CustomerController {

    @Autowired
    private IProductService service;
    

    @GetMapping("/")
    public ModelAndView home(){
       return new ModelAndView("productaddition");
    }


//    @GetMapping("/addproduct")
//    //@RequestMapping(path = "/register",method = RequestMethod.GET)
//    public ModelAndView register() {
//        ModelAndView mv = new ModelAndView("productaddition");
//        return mv;
//    }

    @GetMapping("/processadd")
    public ModelAndView processRegister(@RequestParam("prodid") int id,
                                        @RequestParam("prodname") String prodname,
                                        @RequestParam("price") double price) {
        Product product = new Product();
        product.setProdId(id);
        product.setProdName(prodname);
        product.setProdPrice(price);
        service.save(product);
        ModelAndView mv = new ModelAndView("details", "product", product);
        return mv;
    }

   

    

  




}
