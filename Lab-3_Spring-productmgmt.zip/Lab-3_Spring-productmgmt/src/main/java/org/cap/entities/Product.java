package org.cap.entities;

public class Product {

    private int prodId;
    private double prodPrice; 
    private String prodName;
    
    
    
	public Product() {
		super();
	}
	public Product(int prodId, double prodPrice, String prodName) {
		super();
		this.prodId = prodId;
		this.prodPrice = prodPrice;
		this.prodName = prodName;
	}
	public int getProdId() {
		return prodId;
	}
	public void setProdId(int prodId) {
		this.prodId = prodId;
	}
	public double getProdPrice() {
		return prodPrice;
	}
	public void setProdPrice(double prodPrice) {
		this.prodPrice = prodPrice;
	}
	public String getProdName() {
		return prodName;
	}
	public void setProdName(String prodName) {
		this.prodName = prodName;
	}
	@Override
	public String toString() {
		return "Product [prodId=" + prodId + ", prodPrice=" + prodPrice + ", prodName=" + prodName + "]";
	}
	

    
}
