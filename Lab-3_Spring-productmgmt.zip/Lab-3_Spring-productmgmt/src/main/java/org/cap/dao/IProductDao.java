package org.cap.dao;

import org.cap.entities.Product;

import java.util.List;

public interface IProductDao {

  

    List<Product>fetchAll();

    void save(Product customer);


}
