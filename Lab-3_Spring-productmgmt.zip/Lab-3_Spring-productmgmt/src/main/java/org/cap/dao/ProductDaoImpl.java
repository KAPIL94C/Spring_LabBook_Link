package org.cap.dao;

import org.cap.entities.Product;
import org.springframework.stereotype.Repository;

import java.util.*;

@Repository
public class ProductDaoImpl implements IProductDao {
    static private Map<Integer, Product> store = new HashMap<>();

    static {
    	Product p1=new Product(100,50000,"Laptop");
    	Product p2=new Product(101,40000,"Ipad");
    	Product p3=new Product(102,20000,"Ipod");
    	store.put(p1.getProdId(),p1);
    	store.put(p2.getProdId(),p2);
    	store.put(p3.getProdId(),p3);
    }

    @Override
    public List<Product> fetchAll() {
        Collection<Product>values =store.values();
        List<Product>list=new ArrayList<>(values);
        return list;
    }

    @Override
    public void save(Product product) {
    	
       int id= product.getProdId();
        store.put(id, product);
    }

  

}
