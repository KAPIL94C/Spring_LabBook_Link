package org.cap.service;

import org.cap.dao.IProductDao;
import org.cap.entities.Product;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProductServiceImpl implements IProductService {
    private IProductDao productDao;

   

    public IProductDao getProductDao() {
		return productDao;
	}
    @Autowired
	public void setProductDao(IProductDao productDao) {
		this.productDao = productDao;
	}

	

    @Override
    public List<Product> fetchAll() {
        List<Product>products=productDao.fetchAll();
        return products;
    }

    @Override
    public void save(Product product) {
    	productDao.save(product);
    }

    
}
