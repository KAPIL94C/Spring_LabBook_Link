package org.cap.service;

import org.cap.entities.Product;

import java.util.List;

public interface IProductService {
	  List<Product>fetchAll();

	    void save(Product customer);
}
