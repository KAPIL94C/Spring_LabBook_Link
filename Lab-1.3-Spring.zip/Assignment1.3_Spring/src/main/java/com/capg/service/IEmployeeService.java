package com.capg.service;

import com.capg.entities.Sbu;

import java.util.List;

public interface IEmployeeService {
    List<Sbu>fetchAllEmployees();

}
