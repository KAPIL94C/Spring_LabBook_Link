package com.capg.dao;

import com.capg.entities.Sbu;

import java.util.List;

public interface IEmployeeDao {

    List<Sbu>fetchAllEmployees();
}
