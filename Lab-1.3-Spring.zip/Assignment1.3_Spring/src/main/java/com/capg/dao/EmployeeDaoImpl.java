package com.capg.dao;

import com.capg.entities.Employee;
import com.capg.entities.Sbu;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import java.util.*;

/**
 * @Repository is recommended instead of @Component on EmployeeDaoImpl to show intention
 * Both @Repository and @Component does same job
 */
@Component
public class EmployeeDaoImpl implements IEmployeeDao{

    private Map<Integer,Sbu> map = new HashMap<>();
    List<Employee>  list=new ArrayList();

    public EmployeeDaoImpl(){
    	Employee e=new Employee();
    	e.setEmployeeId(1234);
    	e.setEmployeeName("Harriet");
    	e.setSalary(40000);
    	e.setBusinessUnit("PES-BU");
    	e.setAge(30);
    	Employee e1=new Employee();
    	e1.setEmployeeId(1235);
    	e1.setEmployeeName("Kapil");
    	e1.setSalary(50000);
    	e1.setBusinessUnit("PES-BU");
    	e1.setAge(23);
    	list.add(e1);
    	list.add(e);
    	Sbu sbu=new Sbu();
    	sbu.setSbuId("PES-BU");
    	sbu.setSbuName("Product Engineering Services");
    	sbu.setSbuHead("Kiran Rao");
    	sbu.setEmplist(list);
    	 map.put(1,sbu);	
    	  
    	  
    			System.out.println("inside dao constructor");
     //   System.out.println("beta check in");
    }

	@Override
	public  List<Sbu> fetchAllEmployees() {
		Collection<Sbu> employees  = map.values();
      List<Sbu>  list=new ArrayList<>(employees);
      return list;
	}
    
    


}
