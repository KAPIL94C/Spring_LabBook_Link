package com.capg.entities;

import java.awt.List;
import java.util.ArrayList;

public class Sbu {
	private String sbuId;
	private String sbuName;
	private String sbuHead;
	//private Employee employee;
	
	ArrayList<Employee> emplist = new ArrayList<Employee>();
  public Sbu(){
  		
  	}
	
	public ArrayList<Employee> getEmplist() {
		return emplist;
	}
	public void setEmplist(java.util.List<Employee> list) {
		this.emplist = (ArrayList<Employee>) list;
	}
	public String getSbuId() {
		return sbuId;
	}
	public void setSbuId(String sbuId) {
		this.sbuId = sbuId;
	}
	public String getSbuName() {
		return sbuName;
	}
	public void setSbuName(String sbuName) {
		this.sbuName = sbuName;
	}
	public String getSbuHead() {
		return sbuHead;
	}
	public void setSbuHead(String sbuHead) {
		this.sbuHead = sbuHead;
	}

	@Override
	public String toString() {
		return "Sbu [sbuId=" + sbuId + ", sbuName=" + sbuName + ", sbuHead=" + sbuHead + ", emplist=" + emplist + "]";
	}

	
	
	
	
	
	
	

}
