package com.capg;

import com.capg.config.JavaConfig;
import com.capg.dao.EmployeeDaoImpl;
import com.capg.dao.IEmployeeDao;
import com.capg.entities.Employee;
import com.capg.service.IEmployeeService;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import java.util.List;
import java.util.Scanner;


public class ProjectMain {

    public static void main(String[] args) {
        //
        //ApplicationContext is the specification
        // implementation we are using is AnnotationConfigApplicationContext
        //
        AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
        //
        //registering configuration class in which configurations are kept
        //
        Class configurationClass= JavaConfig.class;
        context.register(configurationClass);
        context.refresh();
        context.registerShutdownHook();
        //
        //fetching bean by name
        //
   
        
        IEmployeeService service = context.getBean(IEmployeeService.class);
        List<Employee>employees= service.fetchAllEmployees();
        System.out.println("Employee Details");
        System.out.println("----------------------------");
        for (Employee e:employees){
        	System.out.println("Employee ID     :" +e.getEmployeeId());
        	System.out.println("Employee Name   :" +e.getEmployeeName());
        	System.out.println("Employee Salary :" +e.getSalary());
        	System.out.println("Employee BU     :" +e.getBusinessUnit());
        	System.out.println("Employee Age    :" +e.getAge());
        }
        
        
        
    }


}